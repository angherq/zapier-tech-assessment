# assessment-app
A sample zapier app that consumes Wistia API, supported use cases are:
- Health check endpoint
- Create a new wistia project
- List wistia projects

## Tradeoffs
None

## Assumptions that affected this solution
Jest usage seems to work a little different

## AI tools
I use co-pilog with visual studio code, mostly for autocomplete 
