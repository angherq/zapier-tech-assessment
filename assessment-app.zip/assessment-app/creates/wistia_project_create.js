// create a particular wistia_project_create by name
const create_new_project = async (z, bundle) => {
  const response = await z.request({
    method: 'POST',
    url: 'https://api.wistia.com/v1/projects',
    body: {
      name: bundle.inputData.name,
      adminEmail: bundle.inputData.adminEmail,
      public: bundle.inputData.is_public
    }
  });
  return response.data;
};

module.exports = {
  key: 'wistia_project_create',
  noun: 'Wistia_project_create',
  display: {
    label: 'Create Wistia_project_create',
    description: 'Creates a new wistia_project_create, probably with input from previous steps.'
  },
  operation: {
    perform: create_new_project,
    inputFields: [
      {key: 'name', required: true},
      {key: 'adminEmail', label: 'Admin Email', required: true},
      {key: 'is_public', label: 'Is Public', required: true, type: 'boolean'}
    ],
    sample: {
      id: 1,
      name: 'Test',
      description: '',
      mediaCount: 0,
      created: '2023-10-10T00:00:00Z',
      updated: '2023-10-10T00:00:00Z',
      hashedId: 'abc123',
      public: true,
      publicId: 'my-public-id',
      anonymousCanUpload: false,
      anonymousCanDownload: false,
    },
    outputFields: [
      {key: 'id', label: 'Project ID'},
      {key: 'name', label: 'Project Name'},
      {key: 'description', label: 'Description'},
      {key: 'mediaCount', label: 'Media Count'},
      {key: 'created', label: 'Created At'},
      {key: 'updated', label: 'Updated At'},
      {key: 'hashedId', label: 'Hashed ID'},
      {key: 'public', label: 'Is Public'},
      {key: 'publicId', label: 'Public ID'},
      {key: 'anonymousCanUpload', label: 'Anonymous Can Upload'},
      {key: 'anonymousCanDownload', label: 'Anonymous Can Download'}
    ]
  }
};
