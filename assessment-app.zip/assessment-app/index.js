const getWistiaHealthCheck = require("./triggers/wistia_health_check");

const createWistiaProjectCreate = require("./creates/wistia_project_create");

const getWistiaProjectList = require("./triggers/wistia_project_list");

const addAuthHeader = (request, z, bundle) => {
  const apiKey = bundle.authData?.apiKey || process.env.wistia_apiKey;
  request.headers['Authorization'] = `Bearer ${apiKey}`;
  return request;
};

const handleHTTPError = (response, z) => {
  if (response.status >= 400) {
    throw new Error(`Unexpected status code ${response.status}`);
  }
  return response;
};

module.exports = {
  // This is just shorthand to reference the installed dependencies you have.
  // Zapier will need to know these before we can upload.
  version: require('./package.json').version,
  platformVersion: require('zapier-platform-core').version,

  authentication: {
    type: 'custom',
    fields: [{ key: 'apiKey', type: 'string' }],
    test: async (z, bundle) => {
      const response = await z.request('http://57b20fb546b57d1100a3c405.mockapi.io/api/me');
      return response.data;
    },
  },

  // If you want your trigger to show up, you better include it here!
  triggers: {
    [getWistiaHealthCheck.key]: getWistiaHealthCheck,
    [getWistiaProjectList.key]: getWistiaProjectList
  },

  // If you want your searches to show up, you better include it here!
  searches: {},

  // If you want your creates to show up, you better include it here!
  creates: {
    [createWistiaProjectCreate.key]: createWistiaProjectCreate
  },

  resources: {},

  beforeRequest: [
    addAuthHeader,
  ],
  afterResponse: [
    handleHTTPError,
  ],
};
