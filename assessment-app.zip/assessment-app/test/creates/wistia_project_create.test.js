const zapier = require('zapier-platform-core');

// Use this to make test calls into your app:
const App = require('../../index');
const appTester = zapier.createAppTester(App);
// read the `.env` file into the environment, if available
zapier.tools.env.inject();

describe('creates.wistia_project_create', () => {
  it('should create a new project', async () => {
    const bundle = { inputData: {name:"Project 1",adminEmail:"angherq@outlook.com",is_public:"true"}};

    // Mock wistia API request
    const mockRequest = jest.fn().mockResolvedValue({
      status: 201,
      data: {
        id: 'mock-project-123',
        name: 'Project 1',
        adminEmail: 'angherq@outlook.com',
        is_public: true,
        created: '2025-09-08T10:00:00Z'
      }
    });
    bundle.z = { request: mockRequest };

    const results = await appTester(App.creates['wistia_project_create'].operation.perform, bundle);
    expect(results).toBeDefined();
    expect(typeof results.id).toBe('number');
    expect(results.name).toEqual('Project 1');
  });
});
