const zapier = require('zapier-platform-core');

// Use this to make test calls into your app:
const App = require('../../index');
const appTester = zapier.createAppTester(App);
// read the `.env` file into the environment, if available
zapier.tools.env.inject();

describe('triggers.wistia_health_check', () => {
  it('should return a healthy status', async () => {
    const bundle = { inputData: {} };

    const results = await appTester(App.triggers['wistia_health_check'].operation.perform, bundle);
    expect(results).toBeDefined();
    expect(results[0].status).toEqual('healthy');
    expect(typeof results[0].id).toBe('string');
  });
});
