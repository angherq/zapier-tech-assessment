const zapier = require('zapier-platform-core');

// Use this to make test calls into your app:
const App = require('../../index');
const appTester = zapier.createAppTester(App);
// read the `.env` file into the environment, if available
zapier.tools.env.inject();

describe('triggers.wistia_project_list', () => {
  it('should list all projects', async () => {
    const bundle = { inputData: {} };

    const results = await appTester(App.triggers['wistia_project_list'].operation.perform, bundle);
    expect(results).toBeDefined();
    expect(results.length).toBeGreaterThan(0);
    expect(typeof results[0].id).toBe('number');
    expect(typeof results[0].name).toBe('string');
  });
});
