// triggers a new wistia-health-check
const check = async (z, bundle) => {
  await z.request({
    url: 'https://api.wistia.com/v1/medias.json',
  });
  return [{"id": Date.now().toString(), "status": "healthy"}]
};

module.exports = {
  key: 'wistia_health_check',
  noun: 'Wistia-health-check',
  display: {
    label: 'New Wistia-health-check',
    description: 'Triggers when a new wistia-health-check is created.'
  },
  operation: {
    perform: check,
    inputFields: [],
    sample: {
      id: '12345',
      status: 'healthy'
    },
    outputFields: [
      { key: 'id', label: 'ID' },
      { key: 'status', label: 'Status' }
    ]
  }
};
