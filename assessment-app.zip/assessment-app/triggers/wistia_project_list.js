// triggers on a new wistia_project_list with a certain tag
const list_all_projects = async (z, bundle) => {
  const response = await z.request({
    url: 'https://api.wistia.com/v1/projects'
  });
  return response.data;
};

module.exports = {
  key: 'wistia_project_list',
  noun: 'Wistia_project_list',
  display: {
    label: 'New Wistia_project_list',
    description: 'Triggers when a new wistia_project_list is created.'
  },
  operation: {
    perform: list_all_projects,
    inputFields: [],
    sample: {
      "id": 10098720,
      "public": true,
      "description": null,
      "name": "Project 1",
      "mediaCount": 0,
      "created": "2025-09-09T03:06:42+00:00",
      "updated": "2025-09-09T03:06:42+00:00",
      "hashedId": "jenfc8kfej",
      "anonymousCanUpload": false,
      "anonymousCanDownload": false,
      "publicId": "jenfc8kfej"
    },
    outputFields: [
      { key: 'id', label: 'Project ID' },
      { key: 'public', label: 'Is Public' },
      { key: 'description', label: 'Description' },
      { key: 'name', label: 'Project Name' },
      { key: 'mediaCount', label: 'Media Count' },
      { key: 'created', label: 'Created At' },
      { key: 'updated', label: 'Updated At' },
      { key: 'hashedId', label: 'Hashed ID' },
      { key: 'anonymousCanUpload', label: 'Anonymous Can Upload' },
      { key: 'anonymousCanDownload', label: 'Anonymous Can Download' },
      { key: 'publicId', label: 'Public ID' }
    ]
  }
};
